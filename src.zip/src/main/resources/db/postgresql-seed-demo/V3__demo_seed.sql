-- Demo data for the local PostgreSQL profile only.
INSERT INTO app_user (id, role, first_name, middle_name, last_name, full_name, email, mobile, house_street, barangay, city, province, password_hash, status, initials, job_title, must_change_password, verification_code) VALUES
  ('U-1001', 'owner', 'Maria', NULL, 'Santos', 'Maria Santos', 'resident@petcare.local', '0917 123 4567', 'Purok 3', 'Balibago', 'Santa Rosa', 'Laguna', '$2a$10$YNwPnD2t9tGIR4ha5QgoJ.yoQ6EB210krayAvG9qk1l1VmJ23HN8y', 'Active', NULL, NULL, FALSE, NULL),
  ('U-1002', 'owner', 'Ana', NULL, 'Reyes', 'Ana Reyes', 'ana.reyes@email.com', '0919 345 6789', 'Purok 1', 'Dita', 'Santa Rosa', 'Laguna', '$2a$10$1pc6B7v874KBA.3IQegxM.5gtZCi7IfLMVNvwk9zwaBggjlhOfY32', 'Active', NULL, NULL, FALSE, NULL),
  ('U-1003', 'owner', 'Juan', NULL, 'Dela Cruz', 'Juan Dela Cruz', 'juan.delacruz@email.com', '0918 234 5678', 'Purok 5', 'Pooc', 'Santa Rosa', 'Laguna', '$2a$10$ZYIWJcpKd28TF9Y3AcNEZedEv8b9se6DiFdB.Xjrw1lfyUMvj1OSS', 'Active', NULL, NULL, FALSE, NULL),
  ('U-1004', 'owner', 'Pedro', NULL, 'Villanueva', 'Pedro Villanueva', 'pedro.villanueva@email.com', '0922 678 9012', 'Purok 7', 'Pooc', 'Santa Rosa', 'Laguna', '$2a$10$J8d5vAaokjfHgLs2UxsFw.xN2cuDtqWY/6jbnThtJ.wcxCUka7xU2', 'Active', NULL, NULL, FALSE, NULL),
  ('U-2001', 'staff', NULL, NULL, NULL, 'Rowena Tan', 'staff@petcare.local', NULL, NULL, NULL, NULL, NULL, '$2a$10$bFqWB56a/xrhvULBGHTi3u6SBLqlX1SjEc6tBkx6x0mIyxHULWHTO', 'Active', 'RT', 'CVO Staff / Veterinarian', FALSE, NULL),
  ('U-2002', 'staff', NULL, NULL, NULL, 'Miguel Alonzo', 'miguel.alonzo@santarosalaguna.gov.ph', NULL, NULL, NULL, NULL, NULL, '$2a$10$oA.sReuV.xNRV.Z1KPAtSew4EZBx.p1Up8hgFi06i3o0XHOcUxmcm', 'Active', 'MA', 'CVO Staff', FALSE, NULL),
  ('U-3001', 'admin', NULL, NULL, NULL, 'Jose Dizon', 'admin@petcare.local', NULL, NULL, NULL, NULL, NULL, '$2a$10$u/4Cwutns/8PdW0AnwAPD.chZHZY4FXhbYSWIJPr4mzuhn1l0gb1m', 'Active', 'JD', 'System Administrator', FALSE, NULL);

INSERT INTO pet (id, owner_id, name, species, breed, sex, dob, color, barangay, registration_status, registered_date, registration_source, weight_kg, health_status, health_notes, rabies_status, last_rabies, deworming_status, last_deworming, proof_of_residency, microchip, microchip_status, kapon_status, kapon_date, photo_url) VALUES
  ('P-1042', 'U-1001', 'Buddy', 'Dog', 'Aspin', 'Male', '2024-05-10', 'Brown, white chest', 'Balibago', 'Verified', '2026-01-15', 'Owner', 9.5, 'Apparently Healthy', NULL, 'Updated', '2026-02-10', 'Updated', '2026-07-01', 'Verified at Barangay', NULL, 'Not Microchipped', NULL, NULL, 'https://images.unsplash.com/photo-1543466835-00a7907e9de1?auto=format&fit=crop&w=300&q=80'),
  ('P-1043', 'U-1001', 'Luna', 'Dog', 'Aspin', 'Female', '2025-07-03', 'Fawn, black muzzle', 'Balibago', 'Verified', '2025-07-10', 'Owner', 6.2, 'Apparently Healthy', NULL, 'Unknown', NULL, 'Unknown', NULL, 'Verified at Barangay', NULL, 'Not Microchipped', NULL, NULL, 'https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?auto=format&fit=crop&w=300&q=80'),
  ('P-1046', 'U-1001', 'Max', 'Dog', 'Aspin', 'Male', '2026-05-01', 'Golden, white socks', 'Balibago', 'Verified', '2026-05-20', 'Owner', 4.4, 'Apparently Healthy', NULL, 'Updated', '2026-06-15', 'Updated', '2026-06-15', 'Verified at Barangay', NULL, 'Not Microchipped', NULL, NULL, 'https://images.unsplash.com/photo-1552053831-71594a27632d?auto=format&fit=crop&w=300&q=80'),
  ('P-1047', 'U-1001', 'Bruno', 'Dog', 'Aspin Mix', 'Male', '2025-01-10', 'Black, tan markings', 'Balibago', 'Verified', '2026-02-01', 'Owner', 7, 'For Verification', 'Owner reports occasional limping; needs CVO physical exam.', 'Updated', '2026-03-05', 'Unknown', NULL, 'Submitted, Pending Verification', NULL, 'Not Microchipped', NULL, NULL, 'https://images.unsplash.com/photo-1596492784531-6e6eb5ea9993?auto=format&fit=crop&w=300&q=80'),
  ('P-1044', 'U-1003', 'Milo', 'Dog', 'Shih Tzu', 'Male', '2022-03-02', 'White, tan patches', 'Pooc', 'Verified', '2022-03-20', 'Owner', 5.8, 'Apparently Healthy', NULL, 'Updated', '2026-07-27', 'Updated', '2026-07-27', 'Verified at Barangay', NULL, 'Not Microchipped', NULL, NULL, 'https://images.unsplash.com/photo-1596492784531-6e6eb5ea9993?auto=format&fit=crop&w=300&q=80'),
  ('P-1045', 'U-1002', 'Coco', 'Dog', 'Aspin', 'Female', '2026-01-08', 'Black and tan', 'Dita', 'Verified', '2026-02-12', 'Owner', 3.6, 'Apparently Healthy', NULL, 'Updated', '2026-06-01', 'Updated', '2026-06-01', 'Verified at Barangay', NULL, 'Not Microchipped', NULL, NULL, 'https://images.unsplash.com/photo-1537151608828-ea2b11777ee8?auto=format&fit=crop&w=300&q=80'),
  ('P-1049', 'U-1004', 'Rocky', 'Dog', 'Aspin', 'Male', '2025-02-14', 'Black, white paws', 'Pooc', 'Pending', NULL, 'Owner', 8.1, 'Apparently Healthy', NULL, 'Unknown', NULL, 'Unknown', NULL, 'Submitted, Pending Verification', NULL, 'Not Microchipped', NULL, NULL, 'https://images.unsplash.com/photo-1552053831-71594a27632d?auto=format&fit=crop&w=300&q=80');

INSERT INTO pet_registration (id, pet_id, owner_id, status, submitted_date, source, rejection_reason) VALUES
  ('REG-1002', 'P-1049', 'U-1004', 'Pending', '2026-08-11', 'Owner', NULL);

INSERT INTO service_request (id, pet_id, owner_id, service_name, remarks, submitted_date, source, staff_decision, decision_date, rejection_reason, status) VALUES
  ('REQ-3301', 'P-1042', 'U-1001', 'Anti-Rabies Vaccination', NULL, '2026-01-20', 'Owner', 'Approved', '2026-01-22', NULL, 'Completed'),
  ('REQ-3302', 'P-1044', 'U-1003', 'Microchipping', NULL, '2026-08-10', 'Owner', 'Pending', NULL, NULL, 'For Review');

INSERT INTO eligibility_assessment (id, request_id, classification, assessed_date) VALUES
  (1, 'REQ-3301', 'ELIGIBLE', '2026-01-21');

INSERT INTO eligibility_assessment_criterion (assessment_id, seq, label, actual_value, result, basis) VALUES
  (1, 1, 'Pet Registration', 'Verified', 'PASS', 'Pet registration is verified.'),
  (1, 2, 'Minimum Applicable Age', '1y 3m', 'PASS', 'Pet is at least 3 months old.'),
  (1, 3, 'Recent Anti-Rabies Vaccination', 'No prior record on file', 'PASS', 'No anti-rabies vaccination recorded within the past 12 months.'),
  (1, 4, 'Medical Restriction', 'Cleared', 'PASS', 'No medical restriction was recorded at the time of assessment.');

SELECT setval(pg_get_serial_sequence('eligibility_assessment','id'), 1, TRUE);

INSERT INTO service_record (request_id, record_date, staff_name, remarks, vaccine_type, batch_number, next_due, microchip_number, procedure_date, post_remarks) VALUES
  ('REQ-3301', '2026-08-02', 'Dr. Rowena Tan, DVM', 'Routine booster administered, no adverse reaction observed.', 'Rabisin', 'AR-2026-0417', '2027-08-02', NULL, NULL, NULL);

INSERT INTO shelter_pet (id, name, species, breed, sex, age_text, description, temperament, status, intake_date, photo_url) VALUES
  ('S-201', 'Brownie', 'Dog', 'Aspin Mix', 'Male', '~1 year', 'Brownie was surrendered by a relocating family and has been at the CVO shelter since July.', 'Friendly, good with children, house-trained.', 'Available', '2026-07-02', 'https://images.unsplash.com/photo-1543466835-00a7907e9de1?auto=format&fit=crop&w=300&q=80'),
  ('S-202', 'Lucky', 'Dog', 'Aspin', 'Female', '~2 years', 'Lucky was rescued from a barangay flood evacuation site and has fully recovered.', 'Calm, gentle, good with other pets.', 'Available', '2026-06-20', 'https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?auto=format&fit=crop&w=300&q=80'),
  ('S-203', 'Tosca', 'Dog', 'Aspin Mix', 'Female', '~8 months', 'Tosca was found as a stray puppy near the public market and was brought in for shelter care.', 'Playful, energetic, still learning basic commands.', 'Available', '2026-08-01', 'https://images.unsplash.com/photo-1537151608828-ea2b11777ee8?auto=format&fit=crop&w=300&q=80');

